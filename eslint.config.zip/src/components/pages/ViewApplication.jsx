export default function ViewApplication(){
    return(
        <>
        </>
    )
}